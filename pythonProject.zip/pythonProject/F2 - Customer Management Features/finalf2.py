import datetime
import random
import time

class Customer:
    # Class variable to keep track of customer count
    customer_count = 0

    def __init__(self):
        # Increment customer count and assign an identifier
        Customer.customer_count += 1
        self.customer_id = f"C{Customer.customer_count}"
        self.num_items = random.randint(1, 30)  # Randomly generate the number of items for each customer
        self.lottery_ticket = False  # Initialize the lottery ticket status to False

    def get_num_items(self):
        return self.num_items

    def calculate_processing_time(self, cashier_time=4, self_service_time=6):
        if self.num_items <= 0:
            return 0  # No processing time for an empty basket

        if self.num_items <= 5:
            return self.num_items * cashier_time
        else:
            return self.num_items * self_service_time

    def award_lottery_ticket(self):
        if self.num_items >= 10:
            self.lottery_ticket = True

    def display_customer_details(self):
        print("### Customer details ###")
        print(f"{self.customer_id} -> items in basket: {self.num_items}, ", end="")
        if self.lottery_ticket:
            print("wins a lottery ticket!")
        else:
            print("hard luck, no lottery ticket this time!", end="")
        print(f"time to process basket at cashier till: {self.calculate_processing_time()} Secs.")
        print(f"time to process basket at self-service till: {self.calculate_processing_time(self_service_time=6)} Secs.")
        if self.lottery_ticket:
            print("### Lucky customer ###")
        print("")

# Example usage:
C1 = Customer()
C2 = Customer()
C3 = Customer()

customers = [C1, C2, C3]

for customer in customers:
    customer.award_lottery_ticket()
    customer.display_customer_details()
