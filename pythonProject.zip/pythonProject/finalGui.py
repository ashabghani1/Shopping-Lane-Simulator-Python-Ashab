# Importing necessary modules from tkinter and other libraries
import tkinter as tk
from tkinter import messagebox
import threading
import random
import time

# Class definition for a checkout lane in the supermarket
class CheckoutLane:
    def __init__(self, is_self_service=False):
        # Initializing attributes for the checkout lane
        self.is_self_service = is_self_service
        self.customers = []  # List to store customer information
        self.max_customers = 15 if is_self_service else 5  # Maximum number of customers in the lane
        self.is_open = False  # Flag to indicate whether the lane is open or closed
        self.created_at = time.time()  # Timestamp when the lane is created

    def open_lane(self):
        # Method to open the checkout lane and print a corresponding message
        self.is_open = True
        print(f"Lane {'Self-Service' if self.is_self_service else 'Regular'} opened at {time.ctime(self.created_at)}")

    def close_lane(self):
        # Method to close the checkout lane and print a corresponding message
        self.is_open = False
        print(f"Lane {'Self-Service' if self.is_self_service else 'Regular'} closed")

    def add_customer(self, items):
        # Method to add a customer to the lane based on the number of items
        if self.is_self_service and items <= 10:
            self.customers.append({"items": items, "checkout_time": items})
            print(f"Customer joined {'Self-Service' if self.is_self_service else 'Regular'} Lane with {items} items")
        elif not self.is_self_service:
            self.customers.append({"items": items, "checkout_time": items})
            print(f"Customer joined {'Self-Service' if self.is_self_service else 'Regular'} Lane with {items} items")
        else:
            print(f"Customer turned away from Self-Service Lane - Items more than 10")

    def checkout(self):
        # Method to process checkout for all customers in the lane
        for customer in self.customers:
            print(f"Processing customer at {'Self-Service' if self.is_self_service else 'Regular'} Lane with {customer['items']} items")
            time.sleep(customer["items"])  # Simulating checkout time
            print(f"Customer at {'Self-Service' if self.is_self_service else 'Regular'} Lane with {customer['items']} items checked out")
        self.customers = []  # Clearing the list after checkout

    def get_status(self):
        # Method to get the current status of the checkout lane
        return f"{self.__str__()} -> {'* ' * len(self.customers)}" if self.is_open else f"{self.__str__()} -> closed"

    def __str__(self):
        # Method to represent the object as a string
        return f"L{self.created_at:.0f} ({'Slf' if self.is_self_service else 'Reg'})"

# Class definition for a regular checkout lane, inheriting from CheckoutLane
class RegularCheckoutLane(CheckoutLane):
    def __init__(self):
        # Initializing a regular checkout lane using the parent class constructor
        super().__init__(is_self_service=False)

# Class definition for a self-service checkout lane, inheriting from CheckoutLane
class SelfServiceCheckoutLane(CheckoutLane):
    def __init__(self):
        # Initializing a self-service checkout lane using the parent class constructor
        super().__init__(is_self_service=True)

    def add_customer(self, items):
        # Overriding the add_customer method for the self-service lane to handle items more than 10
        if items <= 10:
            super().add_customer(items)
        else:
            print(f"Customer turned away from Self-Service Lane - Items more than 10")

# Function to generate a random number of items for a customer
def generate_random_items():
    return random.randint(1, 30)

# Function to display the current status of all checkout lanes
def display_lane_status(total_customers, lanes):
    print(f"\nTotal number of customers waiting to check out at {time.strftime('%H:%M')} is: {total_customers}")
    for lane in lanes:
        print(lane.get_status())

# Function to start the simulation
def start_simulation():
    global simulation_ended
    simulation_ended = False
    start_time = time.time()
    display_current_time()

    # Adding a random number of initial customers
    for _ in range(random.randint(1, 10)):
        num_items = random.randint(1, 30)
        customer = Customer(num_items)
        checkout_system.update_lane_statuses()
        customer.display_customer_details()
        customer.award_lottery_ticket()
        customer.display_customer_details()
        customer.interact_with_lane(checkout_system)

    # Running the simulation for 30 seconds
    while not simulation_ended and time.time() - start_time < 30:
        if int(time.time() - start_time) % 2 == 0:
            display_current_time()

        for lane in checkout_system.lanes:
            # Randomly making customers leave the lane
            if random.random() < 0.2 and len(lane.customers_in_line) > 0:
                leaving_customer = random.choice(lane.customers_in_line)[0]
                leaving_customer.leave_lane(lane)

            # Randomly adding new customers
            if random.random() < 0.3:
                num_items = random.randint(1, 30)
                new_customer = Customer(num_items)
                checkout_system.update_lane_statuses()
                new_customer.display_customer_details()
                new_customer.interact_with_lane(checkout_system)

        checkout_system.redistribute_customers()  # Redistributing customers in regular lanes
        checkout_system.update_lane_statuses()
        time.sleep(4)

        if int(time.time() - start_time) % 10 == 0:
            display_current_time()

    # Closing regular lanes if they reach 0 customers
    for lane in checkout_system.lanes:
        if 'REG' in lane.lane_name and len(lane.customers_in_line) == 0:
            lane.change_lane_status('closed')

    end_simulation()

# Class definition for the supermarket checkout system
class CheckoutSystem:
    def __init__(self):
        self.lanes = []
        self.create_lanes('REG', 5, 10)
        self.create_lane('SELF', 15)

    def create_lane(self, lane_type, capacity):
        # Method to create a checkout lane and add it to the system
        lane_name = f"L{len(self.lanes) + 1}({lane_type})"
        new_lane = CheckoutLane(lane_name, capacity)
        self.lanes.append(new_lane)
        return new_lane

    def create_lanes(self, lane_type, num_lanes, capacity):
        # Method to create multiple lanes of the same type
        for i in range(num_lanes):
            self.create_lane(lane_type, capacity)

    def close_lane(self, lane_name):
        # Method to close a specific checkout lane
        for lane in self.lanes:
            if lane.lane_name == lane_name:
                lane.change_lane_status('closed')
                break

    def total_customers_waiting(self):
        # Method to calculate the total number of customers waiting in all lanes
        return sum(len(lane.customers_in_line) for lane in self.lanes)

    def update_lane_statuses(self):
        # Method to update and display the status of all checkout lanes
        for lane in self.lanes:
            lane.display_status()

    def redistribute_customers(self):
        # Method to redistribute customers in regular lanes if necessary
        for lane in self.lanes:
            if 'REG' in lane.lane_name and len(lane.customers_in_line) > 5:
                available_lanes = [other_lane for other_lane in self.lanes
                                   if 'REG' in other_lane.lane_name and len(other_lane.customers_in_line) < 5]
                if available_lanes:
                    destination_lane = min(available_lanes, key=lambda x: x.get_queue_length())
                    customers_to_move = lane.customers_in_line[:len(lane.customers_in_line)//2]
                    for customer in customers_to_move:
                        destination_lane.add_customer(customer[0], customer[1])
                        customer[0].leave_lane(lane)
                    lane.customers_in_line = lane.customers_in_line[len(lane.customers_in_line)//2:]
                else:
                    self.lanes.remove(lane)
                    self.create_lane('REG', 10)
                    self.create_lane('SELF', 15)

# Function to display the current time
def display_current_time():
    current_time = time.strftime("%H:%M:%S")
    print(f"Current Time: {current_time}")

# Function to end the simulation
def end_simulation():
    global simulation_ended
    simulation_ended = True
    print("\nSimulation ended.")

# Class definition for the Tkinter-based GUI of the supermarket checkout simulation
class CheckoutSystemGUI:
    def __init__(self):
        # Initializing the CheckoutSystemGUI
        self.root = tk.Tk()
        self.root.title("Supermarket Checkout Simulation")

        # Adding buttons to the window
        self.start_button = tk.Button(self.root, text="Start Simulation", command=self.start_simulation)
        self.start_button.pack()

        self.run_feature_button = tk.Button(self.root, text="Run Feature", command=self.run_feature)
        self.run_feature_button.pack()

        self.stop_button = tk.Button(self.root, text="Stop Simulation", command=self.stop_simulation)
        self.stop_button.pack()

        self.exit_button = tk.Button(self.root, text="Exit", command=self.exit_program)
        self.exit_button.pack()

    def start_simulation(self):
        # Starting the simulation in a separate thread to avoid freezing the GUI
        simulation_thread = threading.Thread(target=start_simulation)
        simulation_thread.start()

    def run_feature(self):
        # Running the selected feature (F1 or F2) - Placeholder for actual implementation
        messagebox.showinfo("Feature Run", "Running the selected feature (F1 or F2)")

    def stop_simulation(self):
        # Stopping the simulation
        stop_simulation()

    def exit_program(self):
        # Exiting the program
        self.root.destroy()

    def run(self):
        # Running the Tkinter main loop
        self.root.mainloop()

if __name__ == "__main__":
    # Create an instance of CheckoutSystemGUI
    gui = CheckoutSystemGUI()

    # Run the Tkinter main loop
    gui.run()
