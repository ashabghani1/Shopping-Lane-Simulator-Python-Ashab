import random  # Importing the random module for generating random numbers
import time  # Importing the time module for handling time-related operations


class CheckoutLane:
    def __init__(self, is_self_service=False):
        # Initializing the CheckoutLane object with default or specified parameters
        self.is_self_service = is_self_service
        self.customers = []  # List to store customer information
        self.max_customers = 15 if is_self_service else 5  # Maximum number of customers in the lane
        self.is_open = False  # Flag to indicate whether the lane is open or closed
        self.created_at = time.time()  # Timestamp when the lane is created

    def open_lane(self):
        # Method to open the checkout lane and print a corresponding message
        self.is_open = True
        print(f"Lane {'Self-Service' if self.is_self_service else 'Regular'} opened at {time.ctime(self.created_at)}")

    def close_lane(self):
        # Method to close the checkout lane and print a corresponding message
        self.is_open = False
        print(f"Lane {'Self-Service' if self.is_self_service else 'Regular'} closed")

    def add_customer(self, items):
        # Method to add a customer to the lane based on the number of items
        if self.is_self_service and items <= 10:
            self.customers.append({"items": items, "checkout_time": items})
            print(f"Customer joined {'Self-Service' if self.is_self_service else 'Regular'} Lane with {items} items")
        elif not self.is_self_service:
            self.customers.append({"items": items, "checkout_time": items})
            print(f"Customer joined {'Self-Service' if self.is_self_service else 'Regular'} Lane with {items} items")
        else:
            print(f"Customer turned away from Self-Service Lane - Items more than 10")

    def checkout(self):
        # Method to process checkout for all customers in the lane
        for customer in self.customers:
            print(f"Processing customer at {'Self-Service' if self.is_self_service else 'Regular'} Lane with {customer['items']} items")
            time.sleep(customer["items"])  # Simulating checkout time
            print(f"Customer at {'Self-Service' if self.is_self_service else 'Regular'} Lane with {customer['items']} items checked out")
        self.customers = []  # Clearing the list after checkout

    def get_status(self):
        # Method to get the current status of the checkout lane
        return f"{self.__str__()} -> {'* ' * len(self.customers)}" if self.is_open else f"{self.__str__()} -> closed"

    def __str__(self):
        # Method to represent the object as a string
        return f"L{self.created_at:.0f} ({'Slf' if self.is_self_service else 'Reg'})"


class RegularCheckoutLane(CheckoutLane):
    def __init__(self):
        # Initializing the RegularCheckoutLane object using the parent class constructor
        super().__init__(is_self_service=False)


class SelfServiceCheckoutLane(CheckoutLane):
    def __init__(self):
        # Initializing the SelfServiceCheckoutLane object using the parent class constructor
        super().__init__(is_self_service=True)

    def add_customer(self, items):
        # Overriding the add_customer method for self-service lane to handle items more than 10
        if items <= 10:
            super().add_customer(items)
        else:
            print(f"Customer turned away from Self-Service Lane - Items more than 10")


def generate_random_items():
    # Function to generate a random number of items for a customer
    return random.randint(1, 30)


def display_lane_status(total_customers, lanes):
    # Function to display the current status of all checkout lanes
    print(f"\nTotal number of customers waiting to check out at {time.strftime('%H:%M')} is: {total_customers}")
    for lane in lanes:
        print(lane.get_status())


def main():
    # Creating instances of regular and self-service checkout lanes
    regular_lanes = [RegularCheckoutLane() for _ in range(5)]
    self_service_lane = SelfServiceCheckoutLane()
    lanes = regular_lanes + [self_service_lane]

    # Initial setup: opening the self-service and one regular lane
    self_service_lane.open_lane()
    regular_lanes[0].open_lane()

    # Random customers joining at the start
    for lane in regular_lanes:
        lane.add_customer(generate_random_items())
    self_service_lane.add_customer(generate_random_items())

    start_time = time.time()

    # Running the simulation for 5 minutes
    while time.time() - start_time < 300:
        # Generate new customers at random intervals
        time.sleep(random.uniform(1, 5))
        for lane in regular_lanes:
            lane.add_customer(generate_random_items())
        self_service_lane.add_customer(generate_random_items())

        # Check and process lanes
        total_customers = sum(len(lane.customers) for lane in lanes)
        display_lane_status(total_customers, lanes)

        for lane in lanes:
            if not lane.is_open:
                if lane.customers:
                    lane.open_lane()
            else:
                if not lane.customers:
                    lane.close_lane()
                else:
                    lane.checkout()


if __name__ == "__main__":
    main()
