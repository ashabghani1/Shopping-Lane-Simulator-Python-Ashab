import tkinter as tk
import random

class CheckoutLane:
    def __init__(self, lane_type, capacity):
        self.lane_type = lane_type
        self.capacity = capacity
        self.customers_in_line = []  # Empty list for customers
        self.status = 'open'  # Default status when a new lane is opened

    def open_lane(self):
        self.status = 'open'
        print(f"{self.lane_type} lane is now open.")

    def close_lane(self):
        self.status = 'closed'
        print(f"{self.lane_type} lane is now closed.")

    def is_open(self):
        return self.status == 'open'

    def add_customer(self, customer):
        if self.is_open() and len(self.customers_in_line) < self.capacity:
            self.customers_in_line.append(customer)
            print(f"Customer joined {self.lane_type} lane")
        else:
            print(f"No space available or {self.lane_type} lane is closed.")

    def remove_customer(self, customer):
        if customer in self.customers_in_line:
            self.customers_in_line.remove(customer)
            print(f"Customer left {self.lane_type} lane")
        else:
            print(f"Customer not found in {self.lane_type} lane.")

    def display_status(self):
        status = f"{self.lane_type} is {'open' if self.is_open() else 'closed'} with {len(self.customers_in_line)} customer(s) in line."
        print(status)

class Customer:
    def __init__(self):
        pass

    def add_customer_to_lane(self, checkout_system, lane_type):
        for lane in checkout_system.lanes:
            if lane.lane_type == lane_type:
                lane.add_customer(self)
                break

    def leave_lane(self, checkout_system, lane_type):
        for lane in checkout_system.lanes:
            if lane.lane_type == lane_type:
                lane.remove_customer(self)
                break

# Task 1 - Set up Lanes
class CheckoutSystem:
    def __init__(self):
        self.lanes = []  # Gets an empty list to store lanes
        # Create initial lanes
        self.create_lane('regular', 10)
        self.create_lane('self-service', 10)

    def create_lane(self, lane_type, capacity):
        new_lane = CheckoutLane(lane_type, capacity)
        self.lanes.append(new_lane)
        return new_lane

    def close_lane(self, lane_type):
        for lane in self.lanes:
            if lane.lane_type == lane_type:
                lane.close_lane()
                break

    def add_customer(self, lane, customer):
        lane.add_customer(customer)

def update_lane_status():
    status_text.delete(1.0, tk.END)
    for lane in checkout_system.lanes:
        lane_status = f"{lane.lane_type} is {'open' if lane.is_open() else 'closed'} with {len(lane.customers_in_line)} customer(s) in line."
        status_text.insert(tk.END, lane_status + '\n')
    # Schedule the next update after a fixed time interval (in milliseconds)
    if not simulation_ended:
        window.after(2000, update_simulation)

def end_simulation():
    global simulation_ended
    simulation_ended = True
    status_text.insert(tk.END, "\nSimulation ended.")

def start_simulation():
    global simulation_ended
    simulation_ended = False
    for _ in range(random.randint(1, 10)):
        customer = Customer()
        customer.add_customer_to_lane(checkout_system, random.choice(['regular', 'self-service']))
    update_lane_status()

def update_simulation():
    if not simulation_ended:
        # Implement the logic to update the simulation
        for lane in checkout_system.lanes:
            # Simulate some activity in the lanes (for example, customers leaving)
            if random.random() < 0.2 and len(lane.customers_in_line) > 0:
                leaving_customer = random.choice(lane.customers_in_line)
                leaving_customer.leave_lane(checkout_system, lane.lane_type)

            # Simulate some activity in the lanes (for example, customers being added)
            if random.random() < 0.3:
                new_customer = Customer()
                new_customer.add_customer_to_lane(checkout_system, lane.lane_type)

        update_lane_status()

checkout_system = CheckoutSystem()
simulation_ended = False  # Variable to track simulation status

# Create the main window
window = tk.Tk()
window.title("F3 - Overall Simulation System")

# Use pack to display widget
label = tk.Label(window, text="Ashab Ghani and Anas Vorajee")
label.pack()

# Sufficient width
tk.Label(window, text="Checkout Lane Queue", fg="white", bg="Blue", width=20).pack()

# Create a Text widget to display lane status
status_text = tk.Text(window, height=10, width=50)
status_text.pack()

# Create a button to start the simulation
start_button = tk.Button(window, text="Start Simulation", command=start_simulation)
start_button.pack()

# Create a button to end the simulation
end_button = tk.Button(window, text="End Simulation", command=end_simulation)
end_button.pack()

# Start the main event loop
window.mainloop()
