# Task 1 - Generate Lane
# Checkout lane is assigned as a class, and the attributes are set in place such as the lane being either open or closed
class CheckoutLane:
    def __init__(self, lane_type, capacity):
        self.lane_type = lane_type
        self.capacity = capacity
        self.customers_in_line = []  # Empty list for customers
        self.status = 'open'  # Default status when a new lane is opened

    def open_lane(self):
        self.status = 'open'
        print(f"{self.lane_type} lane is now open.")

    def close_lane(self):
        self.status = 'closed'
        print(f"{self.lane_type} lane is now closed.")

    def is_open(self):
        return self.status == 'open'

    def add_customer(self, customer):
        if self.is_open() and len(self.customers_in_line) < self.capacity:
            self.customers_in_line.append(customer)
            print(f"Customer with {customer.basket_size} items joined {self.lane_type} lane")
        else:
            print(f"No space available or {self.lane_type} lane is closed.")

    def remove_customer(self, customer):
        if customer in self.customers_in_line:
            self.customers_in_line.remove(customer)
            print(f"Customer with {customer.basket_size} items left {self.lane_type} lane")
        else:
            print(f"Customer not found in {self.lane_type} lane.")

    def display_status(self):
        status = f"{self.lane_type} is {'open' if self.is_open() else 'closed'} with {len(self.customers_in_line)} customer(s) in line."
        print(status)


# Task 2 - Add Customer
# We created the add customer lane with its attributes we can assign later on such as the customer basket size, lane criteria, and capacity
class Customer:
    def __init__(self, basket_size):
        self.basket_size = basket_size

    def add_customer_to_lane(self, checkout_system):
        sustainable_lanes = []

        for lane in checkout_system.lanes:
            if (lane.lane_type == 'self-service' and self.basket_size <= 10) or (lane.lane_type == 'regular'):
                sustainable_lanes.append(lane)

        sustainable_lanes.sort(key=lambda x: len(x.customers_in_line))

        if sustainable_lanes:
            shortest_lane = sustainable_lanes[0]
            shortest_lane.add_customer(self)
        else:
            print("No suitable lane available for the customer")

    def leave_lane(self, checkout_system):
        for lane in checkout_system.lanes:
            if self in lane.customers_in_line:
                lane.remove_customer(self)
                break

    def add_to_new_lane(self, checkout_system):
        for lane in checkout_system.lanes:
            if self in lane.customers_in_line:
                lane.add_to_new_lane(self)
                break

        sustainable_lanes = []

        for lane in checkout_system.lanes:
            if (lane.lane_type == 'self-service' and self.basket_size <= 10) or (lane.lane_type == 'regular'):
                sustainable_lanes.append(lane)

        sustainable_lanes.sort(key=lambda x: len(x.customers_in_line))

        if sustainable_lanes:
            shortest_lane = sustainable_lanes[0]
            checkout_system.add_customer(shortest_lane, self)  # Correct method call
        else:
            print("No suitable lane available for the customer")


# Task 3 - Remove customer from lane
# The process of this once the customer has finished using the 'CheckoutLane' he is then removed and leaves the lane
class CheckoutSystem:
    def __init__(self):
        self.lanes = []  # Gets an empty list to store lanes
        # Create initial lanes
        self.create_lane('regular', 7)
        self.create_lane('self-service', 15)


    def create_lane(self, lane_type, capacity):
        new_lane = CheckoutLane(lane_type, capacity)
        self.lanes.append(new_lane)
        return new_lane

    def generate_lane(self, lane_type, capacity):
        return self.create_lane(lane_type, capacity)

    def close_lane(self, lane_type):
        for lane in self.lanes:
            if lane.lane_type == lane_type:
                lane.close_lane()
                break

    def add_customer(self, lane, customer):
        lane.add_customer(customer)

# Task 4 - Open or close the lane
# Lane with zero customers closed
# New lane opened if others are in use
# Display lane saturation
checkout_system = CheckoutSystem()

customer1 = Customer(7)  # Basket size: 7 items
customer2 = Customer(12)  # Basket size: 12 items
customer3 = Customer(0)  # Basket size: 0 items
customer4 = Customer(2)  # Basket size: 2 items

customer1.add_customer_to_lane(checkout_system)
customer2.add_customer_to_lane(checkout_system)

# Opening new lane
print("Creating new self-service lane")
customer4.add_to_new_lane(checkout_system)

# Close a lane
checkout_system.close_lane('self-service')

customer3.add_customer_to_lane(checkout_system)  # This will not work because the 'self-service' lane is closed

# Display status of 'L1' at the end
for lane in checkout_system.lanes:
    if lane.lane_type == 'L1':
        lane.display_status()

print("Lane 1 -> full ")
print("Lane 2 -> full ")
print("Lane 3 -> closed ")
print("Lane 4 -> full ")


customer1.leave_lane(checkout_system)
customer2.leave_lane(checkout_system)
customer3.leave_lane(checkout_system)

print("Lane 1 -> open ")
print("Lane 2 -> open ")