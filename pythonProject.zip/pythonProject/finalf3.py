import datetime  # Importing the datetime module for date and time operations
import random  # Importing the random module for generating random numbers
import time  # Importing the time module for handling time-related operations

class Customer:
    # Class variable to keep track of customer count
    customer_count = 0

    def __init__(self, num_items):
        # Increment customer count and assign an identifier
        Customer.customer_count += 1
        self.customer_id = f"C{Customer.customer_count}"
        self.num_items = random.randint(1, 30)  # Randomly generate the number of items for each customer
        self.lottery_ticket = False  # Initialize the lottery ticket status to False

    def get_num_items(self):
        # Method to get the number of items in the customer's basket
        return self.num_items

    def calculate_processing_time(self, cashier_time=4, self_service_time=6):
        # Method to calculate the processing time based on the number of items
        if self.num_items <= 0:
            return 0  # No processing time for an empty basket

        if self.num_items <= 5:
            return self.num_items * cashier_time
        else:
            return self.num_items * self_service_time

    def award_lottery_ticket(self):
        # Method to award a lottery ticket to customers with 10 or more items
        if self.num_items >= 10:
            self.lottery_ticket = True

    def display_customer_details(self):
        # Method to display customer details, including processing times and lottery status
        print("### Customer details ###")
        print(f"{self.customer_id} -> items in basket: {self.num_items}, ", end="")
        if self.lottery_ticket:
            print("wins a lottery ticket!")
        else:
            print("hard luck, no lottery ticket this time!", end="")
        print(f"time to process basket at cashier till: {self.calculate_processing_time()} Secs.")
        print(f"time to process basket at self-service till: {self.calculate_processing_time(self_service_time=6)} Secs.")
        if self.lottery_ticket:
            print("### Lucky customer ###")
        print("")

    def interact_with_lane(self, checkout_system):
        # Method for the customer to interact with a checkout lane in the checkout system
        if self.num_items > 10:
            regular_lanes = [lane for lane in checkout_system.lanes if 'REG' in lane.lane_name]
            if regular_lanes:
                preferred_lane = min(regular_lanes, key=lambda x: x.get_queue_length())
                preferred_lane.add_customer(self, self.num_items)
            else:
                print("No regular lanes available.")
        else:
            preferred_lane = min(checkout_system.lanes, key=lambda x: x.get_queue_length())
            preferred_lane.add_customer(self, self.num_items)

    def leave_lane(self, checkout_lane):
        # Method for the customer to leave a checkout lane
        checkout_lane.remove_customer(self)

class CheckoutLane:
    def __init__(self, lane_name, capacity):
        # Initialize checkout lane with a name and capacity
        self.lane_name = lane_name
        self.capacity = capacity
        self.customers_in_line = []
        self.status = 'open'

    def change_lane_status(self, new_status):
        # Method to change the status of the checkout lane (open/closed)
        self.status = new_status
        print(f"{self.lane_name} lane is now {new_status}.")

    def is_open(self):
        # Method to check if the checkout lane is open
        return self.status == 'open'

    def add_customer(self, customer, num_items):
        # Method to add a customer to the checkout lane if it's open and not at full capacity
        if self.is_open() and len(self.customers_in_line) < self.capacity:
            self.customers_in_line.append((customer, num_items))
            print(f"### Customer details ###")
            print(f"{customer} -> items in basket: {num_items}, time to process basket at {self.lane_name} till: {customer.calculate_processing_time()} Secs.")
            print(f"time to process basket at self-service till: {customer.calculate_processing_time(self_service_time=6)} Secs")
            print("")

    def remove_customer(self, customer):
        # Method to remove a customer from the checkout lane
        if customer in self.customers_in_line:
            self.customers_in_line.remove(customer)
            print(f"Customer left {self.lane_name} lane")
        else:
            print(f"Customer not found in {self.lane_name} lane.")

    def display_status(self):
        # Method to display the status of the checkout lane
        status = f"{self.lane_name} is {'open' if self.is_open() else 'closed'} with {len(self.customers_in_line)} customer(s) in line."
        print(status)

    def get_queue_length(self):
        # Method to get the current length of the checkout lane queue
        return len(self.customers_in_line)

class CheckoutSystem:
    def __init__(self):
        # Initialize the checkout system with a list of checkout lanes
        self.lanes = []
        self.create_lanes('REG', 5, 10)  # Creating 5 regular lanes with a capacity of 10
        self.create_lane('SELF', 15)  # Creating 1 self-service lane with a capacity of 15

    def create_lane(self, lane_type, capacity):
        # Method to create a new checkout lane and add it to the system
        lane_name = f"L{len(self.lanes) + 1}({lane_type})"
        new_lane = CheckoutLane(lane_name, capacity)
        self.lanes.append(new_lane)
        return new_lane

    def create_lanes(self, lane_type, num_lanes, capacity):
        # Method to create multiple checkout lanes of the same type
        for i in range(num_lanes):
            self.create_lane(lane_type, capacity)

    def close_lane(self, lane_name):
        # Method to close a specific checkout lane
        for lane in self.lanes:
            if lane.lane_name == lane_name:
                lane.change_lane_status('closed')
                break

    def total_customers_waiting(self):
        # Method to calculate the total number of customers waiting in all checkout lanes
        return sum(len(lane.customers_in_line) for lane in self.lanes)

    def update_lane_statuses(self):
        # Method to update and display the status of all checkout lanes
        for lane in self.lanes:
            lane.display_status()

    def redistribute_customers(self):
        # Method to redistribute customers from congested regular lanes to other regular lanes
        for lane in self.lanes:
            if 'REG' in lane.lane_name and len(lane.customers_in_line) > 5:
                available_lanes = [other_lane for other_lane in self.lanes
                                   if 'REG' in other_lane.lane_name and len(other_lane.customers_in_line) < 5]
                if available_lanes:
                    destination_lane = min(available_lanes, key=lambda x: x.get_queue_length())
                    customers_to_move = lane.customers_in_line[:len(lane.customers_in_line)//2]
                    for customer in customers_to_move:
                        destination_lane.add_customer(customer[0], customer[1])
                        customer[0].leave_lane(lane)
                    lane.customers_in_line = lane.customers_in_line[len(lane.customers_in_line)//2:]
                else:
                    # If no available lanes, close the congested lane and create new regular and self-service lanes
                    self.lanes.remove(lane)
                    self.create_lane('REG', 10)
                    self.create_lane('SELF', 15)

def display_current_time():
    # Function to display the current time
    current_time = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"Current Time: {current_time}")

def end_simulation():
    # Function to end the simulation
    global simulation_ended
    simulation_ended = True
    print("\nSimulation ended.")

def start_simulation():
    # Function to start the simulation
    global simulation_ended
    simulation_ended = False
    start_time = time.time()
    display_current_time()

    for _ in range(random.randint(1, 10)):
        # Generate random initial customers
        num_items = random.randint(1, 30)
        customer = Customer(num_items)
        checkout_system.update_lane_statuses()
        customer.display_customer_details()
        customer.award_lottery_ticket()
        customer.display_customer_details()
        customer.interact_with_lane(checkout_system)

    while not simulation_ended and time.time() - start_time < 30:  # Run for 30 seconds
        if int(time.time() - start_time) % 2 == 0:
            display_current_time()

        for lane in checkout_system.lanes:
            if random.random() < 0.2 and len(lane.customers_in_line) > 0:
                # Randomly make customers leave lanes
                leaving_customer = random.choice(lane.customers_in_line)[0]
                leaving_customer.leave_lane(lane)

            if random.random() < 0.3:
                # Randomly generate new customers
                num_items = random.randint(1, 30)
                new_customer = Customer(num_items)
                checkout_system.update_lane_statuses()
                new_customer.display_customer_details()
                new_customer.interact_with_lane(checkout_system)

        checkout_system.redistribute_customers()  # Redistribute customers in regular lanes
        checkout_system.update_lane_statuses()
        time.sleep(4)

        if int(time.time() - start_time) % 10 == 0:
            display_current_time()

    # Close regular lanes if they reach 0 customers
    for lane in checkout_system.lanes:
        if 'REG' in lane.lane_name and len(lane.customers_in_line) == 0:
            lane.change_lane_status('closed')

    end_simulation()

# Create an instance of the CheckoutSystem
checkout_system = CheckoutSystem()
simulation_ended = False

# Start the simulation
start_simulation()
