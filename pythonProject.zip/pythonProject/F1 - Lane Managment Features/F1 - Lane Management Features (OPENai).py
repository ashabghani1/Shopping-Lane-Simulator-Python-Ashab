import random
import time

class CheckoutLane:
    def __init__(self, is_self_service=False):
        self.is_self_service = is_self_service
        self.customers = []
        self.max_customers = 15 if is_self_service else 5
        self.is_open = False
        self.created_at = time.time()

    def open_lane(self):
        self.is_open = True
        print(f"Lane {'Self-Service' if self.is_self_service else 'Regular'} opened at {time.ctime(self.created_at)}")

    def close_lane(self):
        self.is_open = False
        print(f"Lane {'Self-Service' if self.is_self_service else 'Regular'} closed")

    def add_customer(self, items):
        if self.is_self_service and items <= 10:
            self.customers.append({"items": items, "checkout_time": items})
            print(f"Customer joined {'Self-Service' if self.is_self_service else 'Regular'} Lane with {items} items")
        elif not self.is_self_service:
            self.customers.append({"items": items, "checkout_time": items})
            print(f"Customer joined {'Self-Service' if self.is_self_service else 'Regular'} Lane with {items} items")
        else:
            print(f"Customer turned away from Self-Service Lane - Items more than 10")

    def checkout(self):
        for customer in self.customers:
            print(f"Processing customer at {'Self-Service' if self.is_self_service else 'Regular'} Lane with {customer['items']} items")
            time.sleep(customer["items"])  # Simulating checkout time
            print(f"Customer at {'Self-Service' if self.is_self_service else 'Regular'} Lane with {customer['items']} items checked out")
        self.customers = []

    def get_status(self):
        return f"{self.__str__()} -> {'* ' * len(self.customers)}" if self.is_open else f"{self.__str__()} -> closed"

    def __str__(self):
        return f"L{self.created_at:.0f} ({'Slf' if self.is_self_service else 'Reg'})"

def generate_random_items():
    return random.randint(1, 30)

def display_lane_status(total_customers, lanes):
    print(f"\nTotal number of customers waiting to check out at {time.strftime('%H:%M')} is: {total_customers}")
    for lane in lanes:
        print(lane.get_status())

def main():
    regular_lanes = [CheckoutLane() for _ in range(5)]
    self_service_lane = CheckoutLane(is_self_service=True)
    lanes = regular_lanes + [self_service_lane]

    # Initial setup
    self_service_lane.open_lane()
    regular_lanes[0].open_lane()

    # Random customers joining at the start
    for lane in regular_lanes:
        lane.add_customer(generate_random_items())
    self_service_lane.add_customer(generate_random_items())

    start_time = time.time()

    while time.time() - start_time < 300:  # Run simulation for 5 minutes
        # Generate new customers at random intervals
        time.sleep(random.uniform(1, 5))
        for lane in regular_lanes:
            lane.add_customer(generate_random_items())
        self_service_lane.add_customer(generate_random_items())

        # Check and process lanes
        total_customers = sum(len(lane.customers) for lane in lanes)
        display_lane_status(total_customers, lanes)

        for lane in lanes:
            if not lane.is_open:
                if lane.customers:
                    lane.open_lane()
            else:
                if not lane.customers:
                    lane.close_lane()
                else:
                    lane.checkout()

if __name__ == "__main__":
    main()
