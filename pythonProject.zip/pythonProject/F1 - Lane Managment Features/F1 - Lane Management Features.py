# Task 1 - Generate Lane
class CheckoutLane:
    def __init__(self, lane_type, capacity):
        self.lane_type = lane_type
        self.capacity = capacity
        self.customers_in_line = []
        self.status = 'open'

    def open_lane(self):
        self.status = 'open'
        print(f"{self.lane_type} lane is now open.")

    def close_lane(self):
        self.status = 'closed'
        print(f"{self.lane_type} lane is now closed.")

    def is_open(self):
        return self.status == 'open'

    def add_customer(self, customer):
        if self.is_open() and len(self.customers_in_line) < self.capacity:
            self.customers_in_line.append(customer)
            print(f"Customer joined {self.lane_type} lane")
        else:
            print(f"No space available or {self.lane_type} lane is closed.")

    def remove_customer(self, customer):
        if customer in self.customers_in_line:
            self.customers_in_line.remove(customer)
            print(f"Customer left {self.lane_type} lane")
            if len(self.customers_in_line) == 0:
                self.close_lane()
        else:
            print(f"Customer not found in {self.lane_type} lane.")

    def display_status(self):
        status = f"{self.lane_type} is {'open' if self.is_open() else 'closed'} with {len(self.customers_in_line)} customer(s) in line."
        print(status)


# Task 2 - Add Customer
class Customer:
    def __init__(self):
        pass

    def add_customer_to_lane(self, checkout_system, lane_type):
        for lane in checkout_system.lanes:
            if lane.lane_type == lane_type:
                lane.add_customer(self)
                break

    def leave_lane(self, checkout_system, lane_type):
        for lane in checkout_system.lanes:
            if lane.lane_type == lane_type:
                lane.remove_customer(self)
                break


# Task 3 - Remove customer from lane
class CheckoutSystem:
    def __init__(self):
        self.lanes = []
        self.create_lane('regular', 7)
        self.create_lane('self-service', 15)

    def create_lane(self, lane_type, capacity):
        new_lane = CheckoutLane(lane_type, capacity)
        self.lanes.append(new_lane)
        return new_lane

    def close_lane(self, lane_type):
        for lane in self.lanes:
            if lane.lane_type == lane_type:
                lane.close_lane()
                break

    def add_customer(self, lane, customer):
        lane.add_customer(customer)

    def all_lanes_closed(self):
        return all(not lane.is_open() for lane in self.lanes)


# Task 4 - Open or close the lane
checkout_system = CheckoutSystem()

# Initial regular lane with 5 customers
for _ in range(5):
    customer = Customer()
    customer.add_customer_to_lane(checkout_system, 'regular')

# Initial self-service lane with 5 customers
for _ in range(5):
    customer = Customer()
    customer.add_customer_to_lane(checkout_system, 'self-service')

# Close a lane
checkout_system.close_lane('self-service')

# Display status of lanes
for lane in checkout_system.lanes:
    lane.display_status()

# Open a new regular lane if both existing lanes are full
if all(len(lane.customers_in_line) == lane.capacity for lane in checkout_system.lanes):
    print("Creating new regular lane")
    checkout_system.create_lane('regular', 7)

# Display status of lanes
for lane in checkout_system.lanes:
    lane.display_status()

# Display status of lanes after opening a new regular lane
for lane in checkout_system.lanes:
    lane.display_status()

# Customers leave lanes
for _ in range(5):
    customer = Customer()
    customer.leave_lane(checkout_system, 'regular')

for _ in range(5):
    customer = Customer()
    customer.leave_lane(checkout_system, 'self-service')

# Display final status of lanes
for lane in checkout_system.lanes:
    lane.display_status()

# End simulation if all lanes are closed
if checkout_system.all_lanes_closed():
    print("All lanes closed. Simulation ended.")
